package batch;

import org.springframework.stereotype.Service;

@Service
public class SavingsAccountDomainService {
    private final SavingsAccountRepository savingsAccountRepository;

    public SavingsAccountDomainService(SavingsAccountRepository savingsAccountRepository) {
        this.savingsAccountRepository = savingsAccountRepository;
    }

    void increaseBalance(Long savingsAccountId) {
        SavingsAccount savingsAccount = savingsAccountRepository.findById(savingsAccountId).orElseThrow(RuntimeException::new);
        savingsAccount.increaseBalance();
        savingsAccountRepository.save(savingsAccount);
    }
}