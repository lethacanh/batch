package batch;

import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
public class BatchService {
    private final SavingsAccountRepository repository;
    private final SavingsAccountDomainService savingsAccountDomainService;

    public BatchService(SavingsAccountRepository repository, SavingsAccountDomainService savingsAccountDomainService) {
        this.repository = repository;
        this.savingsAccountDomainService = savingsAccountDomainService;
    }

    @Transactional
    public void increaseBalance(int numberOfThreads, int itemPerBatch) throws InterruptedException{
        List<Long> allIds = repository.allIds();

        List<Callable<Void>> callableTasks = new ArrayList<>();

        ExecutorService executorService = Executors.newFixedThreadPool(numberOfThreads);


        for (int threadIndex = 1; threadIndex <= numberOfThreads; threadIndex++) {
            List<Long> subList = getSubList(numberOfThreads, allIds, threadIndex);

            Callable<Void> callableTask = () -> {

                increaseBalance(subList, itemPerBatch);
                return null;
            };
            callableTasks.add(callableTask);
        }
        executorService.invokeAll(callableTasks);
        executorService.shutdown();
    }

    private List<Long> getSubList(int numberOfThreads, List<Long> allIds, int i) {
        final int sizeOfSubList = allIds.size() / numberOfThreads;
        int firstIndex = (i - 1) * sizeOfSubList;
        int lastIndex = (i - 1) * sizeOfSubList + sizeOfSubList;
        if (i == numberOfThreads)
            lastIndex = allIds.size();

        List<Long> subList = allIds.subList(firstIndex, lastIndex);
        return subList;
    }

    private void increaseBalance(List<Long> subList, int itemPerBatch) {
        subList.forEach(savingsAccountId -> {
            SavingsAccount savingsAccount = repository.findById(savingsAccountId).orElseThrow(RuntimeException::new);
            savingsAccount.increaseBalance();
            repository.save(savingsAccount);
        });
    }

    @PostConstruct
    void action() throws InterruptedException{
        setupData();
        increaseBalance(7, 3);

        validate();
    }

    private void validate() {
        List<SavingsAccount> all = repository.findAll();
        all.forEach(item -> {
            if(item.balance().compareTo(BigDecimal.valueOf(101_000)) < 0 &&
                    item.balance().compareTo(BigDecimal.valueOf(100_000)) > 0){

            } else {
                System.out.println("!!!!!!!!!!NOK!");

                throw new RuntimeException();
            }
            System.out.println("OK!");
        });
    }


    @Transactional
    void setupData() throws InterruptedException {
        repository.deleteAll();
        for (int i = 1; i < 100; i++) {
            SavingsAccount acc = new SavingsAccount(
                    BigDecimal.valueOf(i));
            repository.save(acc);
        }


    }
}
